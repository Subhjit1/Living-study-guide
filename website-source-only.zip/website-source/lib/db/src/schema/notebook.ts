import { pgTable, serial, text, jsonb } from "drizzle-orm/pg-core";

export const notebookTable = pgTable("study_notebook", {
  id: serial("id").primaryKey(),
  ownerEmail: text("owner_email"),
  data: jsonb("data").notNull(),
});

// Legacy single-owner notebook remains untouched; never assign it to a random signup.
export const accountNotebookTable = pgTable("account_notebooks", {
  userId: text("user_id").primaryKey(),
  data: jsonb("data").notNull(),
});
