import type { ReactNode } from "react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";

export function PageHeader({ eyebrow, title, children, aside }: { eyebrow: string; title: ReactNode; children?: ReactNode; aside?: ReactNode }) {
  return (
    <header className="rise glass glass-edge relative mb-10 flex flex-col gap-6 overflow-hidden rounded-2xl px-6 py-8 md:flex-row md:items-end md:justify-between md:px-10 md:py-10">
      <span aria-hidden className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-[radial-gradient(circle,hsl(var(--violet)/0.35),transparent_70%)]" />
      <div className="relative max-w-2xl">
        <p className="eyebrow mb-3">{eyebrow}</p>
        <h1 className="font-display grad-ink text-4xl font-semibold leading-[1.08] md:text-5xl">{title}</h1>
        {children && <p className="font-reading mt-4 text-lg leading-relaxed text-muted-foreground">{children}</p>}
      </div>
      {aside && <div className="relative">{aside}</div>}
    </header>
  );
}

export function PageSkeleton() {
  return (
    <div className="space-y-6" data-testid="status-loading">
      <Skeleton className="h-4 w-32" />
      <Skeleton className="h-12 w-2/3" />
      <Skeleton className="h-4 w-1/2" />
      <div className="grid gap-4 pt-6 md:grid-cols-2">
        <Skeleton className="h-48" />
        <Skeleton className="h-48" />
      </div>
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="mx-auto max-w-md glass rounded-2xl border border-destructive/30 p-8 text-center" data-testid="status-error">
      <p className="eyebrow mb-2 text-destructive">The notebook did not open</p>
      <p className="font-reading text-lg text-foreground">{message}</p>
      <Button variant="outline" className="mt-6" onClick={onRetry} data-testid="button-retry">
        <RotateCcw className="mr-2 h-4 w-4" /> Try again
      </Button>
    </div>
  );
}

export function EmptyState({ title, body, href, cta }: { title: string; body: string; href?: string; cta?: string }) {
  return (
    <div className="ruled rise glass rounded-2xl border border-dashed border-[hsl(var(--cyan)/0.3)] px-8 py-14 text-center" data-testid="status-empty">
      <p className="font-display text-2xl font-medium text-foreground">{title}</p>
      <p className="font-reading mx-auto mt-3 max-w-md text-base text-muted-foreground">{body}</p>
      {href && cta && (
        <Link href={href} className="mt-6 inline-flex items-center btn-grad rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground" data-testid="link-empty-cta">
          {cta}
        </Link>
      )}
    </div>
  );
}

export function SourceQuote({ quote, sourceTitle, className = "" }: { quote: string; sourceTitle: string; className?: string }) {
  return (
    <figure className={`border-l-2 border-[hsl(var(--cyan)/0.7)] pl-4 ${className}`}>
      <blockquote className="font-reading text-[1.05rem] italic leading-relaxed text-foreground/90">
        <span className="hl">{quote}</span>
      </blockquote>
      <figcaption className="eyebrow mt-2 normal-case tracking-normal">from your notes — {sourceTitle}</figcaption>
    </figure>
  );
}

export function Meter({ value, className = "" }: { value: number; className?: string }) {
  return (
    <div className={`h-2 w-full overflow-hidden rounded-full bg-muted shadow-[inset_0_1px_2px_hsl(232_90%_3%/0.6)] ${className}`}>
      <div className="grad-fill h-full origin-left rounded-full shadow-[0_0_10px_hsl(var(--cyan)/0.45)] transition-transform duration-700" style={{ transform: `scaleX(${Math.max(0, Math.min(1, value))})` }} />
    </div>
  );
}
