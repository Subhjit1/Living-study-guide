import { useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Show, useClerk, useUser } from "@clerk/react";
import { BookOpen, ClipboardCheck, Library, Layers, HelpCircle, Target, LineChart, Settings, Menu, X, LogOut, LogIn, Lock, Eye } from "lucide-react";
import { useAccess, useNotebook, pending, approved, errMsg } from "@/lib/notebook";
import { PageSkeleton, ErrorState } from "@/components/kit";

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

const NAV = [
  { href: "/", label: "Overview", icon: BookOpen },
  { href: "/review", label: "Review", icon: ClipboardCheck, badge: "pending" as const },
  { href: "/library", label: "Library", icon: Library },
  { href: "/flashcards", label: "Flashcards", icon: Layers },
  { href: "/quiz", label: "Quiz", icon: HelpCircle },
  { href: "/study", label: "Study", icon: Target },
  { href: "/understanding", label: "Understanding", icon: LineChart },
  { href: "/settings", label: "Settings", icon: Settings },
];

function Account() {
  const { user } = useUser();
  const { signOut } = useClerk();
  return (
    <>
      <Show when="signed-in">
        <div className="flex items-center gap-3 rounded-md px-2 py-2">
          <div className="grid h-8 w-8 place-items-center rounded-full btn-grad text-xs font-medium text-primary-foreground">
            {(user?.firstName?.[0] ?? user?.primaryEmailAddress?.emailAddress?.[0] ?? "S").toUpperCase()}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm text-sidebar-foreground" data-testid="text-user">{user?.firstName ?? user?.primaryEmailAddress?.emailAddress}</p>
          </div>
          <button onClick={() => signOut({ redirectUrl: basePath || "/" })} className="rounded p-1.5 text-muted-foreground hover:bg-sidebar-accent hover:text-foreground" aria-label="Sign out" data-testid="button-sign-out">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </Show>
      <Show when="signed-out">
        <Link href="/sign-in" className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-sidebar-foreground hover:bg-sidebar-accent" data-testid="link-sign-in">
          <LogIn className="h-4 w-4" /> Sign in
        </Link>
      </Show>
    </>
  );
}

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const [loc] = useLocation();
  const { data, access } = useNotebook();
  const pendingCount = data ? pending(data.cards).length : null;
  const approvedCount = data ? approved(data.cards).length : null;
  const isPreview = access && !access.protectionEnabled;
  return (
    <div className="flex h-full flex-col">
      <div className="px-5 pb-6 pt-7">
        <Link href="/" onClick={onNavigate} className="flex items-center gap-3" data-testid="link-home">
          <span className="float grid h-10 w-10 place-items-center rounded-xl glass glass-edge"><img src={`${basePath}/logo.svg`} alt="" className="h-7 w-7" /></span>
          <div>
            <p className="font-display text-lg font-semibold leading-tight text-sidebar-foreground">Living Study Guide</p>
            <p className="eyebrow text-[0.6rem]">Sociology 101</p>
          </div>
        </Link>
        {data && <p className="font-reading mt-5 text-sm italic leading-snug text-muted-foreground" data-testid="text-notebook-title">{data.title}</p>}
      </div>
      <nav className="flex-1 space-y-0.5 px-3">
        {NAV.map((n) => {
          const active = n.href === "/" ? loc === "/" : loc.startsWith(n.href);
          return (
            <Link key={n.href} href={n.href} onClick={onNavigate} data-testid={`link-nav-${n.label.toLowerCase()}`}
              className={`group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[0.92rem] font-medium transition-all duration-300 ${active ? "bg-[linear-gradient(100deg,hsl(var(--royal)/0.32),hsl(var(--violet)/0.18))] text-sidebar-accent-foreground shadow-[inset_0_1px_0_hsl(0_0%_100%/0.08),0_10px_24px_-14px_hsl(var(--royal)/0.9)]" : "text-sidebar-foreground/75 hover:translate-x-1 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"}`}>
              {active && <span className="absolute left-0 top-2 bottom-2 w-1 rounded-full bg-[hsl(var(--cyan))] shadow-[0_0_10px_hsl(var(--cyan))]" />}
              <n.icon className="h-4 w-4 opacity-80" strokeWidth={1.6} />
              <span className="flex-1">{n.label}</span>
              {n.badge && pendingCount !== null && pendingCount > 0 && (
                <span className="rounded-full bg-[linear-gradient(120deg,hsl(var(--violet)),hsl(322_72%_62%))] px-2 py-0.5 font-mono text-[0.65rem] text-white" data-testid="text-nav-pending">{pendingCount}</span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="space-y-3 border-t border-sidebar-border px-3 py-4">
        {approvedCount !== null && (
          <p className="px-3 font-mono text-[0.68rem] text-muted-foreground">{approvedCount} approved / {pendingCount} awaiting review</p>
        )}
        {access && (
          <div className="mx-3 flex items-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/30 px-2.5 py-1.5 text-xs text-muted-foreground" data-testid="status-access-mode">
            {isPreview ? <Eye className="h-3.5 w-3.5" /> : <Lock className="h-3.5 w-3.5" />}
            {isPreview ? "Open preview — not private" : "Your private notebook"}
          </div>
        )}
        <Account />
      </div>
    </div>
  );
}

export function Ambient() {
  return (
    <div className="ambient" aria-hidden>
      <span className="orb orb-a" />
      <span className="orb orb-b" />
      <span className="orb orb-c" />
      <span className="ring3d" />
    </div>
  );
}

function OwnerGate({ signedIn }: { signedIn: boolean }) {
  const { signOut } = useClerk();
  return (
    <div className="ruled relative flex min-h-[100dvh] items-center justify-center bg-background px-6">
      <Ambient />
      <div className="rise glass glass-edge relative z-10 w-full max-w-md rounded-2xl p-10 text-center">
        <img src={`${basePath}/logo.svg`} alt="" className="mx-auto h-12 w-12" />
        <p className="eyebrow mt-6">Living Study Guide</p>
        <h1 className="font-display grad-ink mt-2 text-3xl font-semibold">This notebook is private.</h1>
        <p className="font-reading mt-3 text-muted-foreground">
          {signedIn ? "Please sign in again to open your notebook." : "Turn your notes into flashcards and quizzes. Sign in or create an account to get your own private notebook. Your notes and progress are visible only to you."}
        </p>
        {signedIn ? (
          <button onClick={() => signOut({ redirectUrl: `${basePath}/sign-in` })} className="btn-grad mt-8 w-full rounded-full bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground" data-testid="button-switch-account">Switch account</button>
        ) : (
          <Link href="/sign-in" className="btn-grad mt-8 block w-full rounded-full bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground" data-testid="link-gate-sign-in">Sign in</Link>
        )}
        {!signedIn && <Link href="/sign-up" className="mt-4 block text-cyan-300 underline underline-offset-4" data-testid="link-gate-sign-up">Create an account</Link>}
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const access = useAccess();
  const [open, setOpen] = useState(false);
  if (access.isLoading) return <div className="mx-auto max-w-4xl p-10"><PageSkeleton /></div>;
  if (access.isError) return <div className="p-10"><ErrorState message={errMsg(access.error)} onRetry={() => access.refetch()} /></div>;
  if (access.data && !access.data.allowed) return <OwnerGate signedIn={access.data.signedIn} />;
  return (
    <div className="min-h-[100dvh] bg-background">
      <Ambient />
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-sidebar-border bg-sidebar/70 backdrop-blur-xl md:block">
        <Sidebar />
      </aside>
      <div className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-[hsl(var(--background)/0.7)] px-4 py-3 backdrop-blur-xl md:hidden">
        <span className="font-display text-lg font-semibold">Living Study Guide</span>
        <button onClick={() => setOpen(true)} aria-label="Open navigation" data-testid="button-open-nav"><Menu className="h-5 w-5" /></button>
      </div>
      {open && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-[hsl(232_80%_3%/0.6)] backdrop-blur-sm" onClick={() => setOpen(false)} />
          <aside className="rise absolute inset-y-0 left-0 w-72 border-r border-sidebar-border bg-sidebar/90 backdrop-blur-xl shadow-xl">
            <button className="absolute right-3 top-3 p-1" onClick={() => setOpen(false)} aria-label="Close navigation" data-testid="button-close-nav"><X className="h-5 w-5" /></button>
            <Sidebar onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}
      <main className="relative z-10 md:pl-64">
        <div className="mx-auto max-w-5xl px-5 py-10 md:px-12 md:py-14">{children}</div>
      </main>
    </div>
  );
}
