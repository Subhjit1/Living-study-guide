import { useQueryClient } from "@tanstack/react-query";
import { useUser } from "@clerk/react";
import {
  useGetAccess,
  getGetAccessQueryKey,
  useGetNotebook,
  getGetNotebookQueryKey,
  type Card,
} from "@workspace/api-client-react";

export function useAccess() {
  const { user, isLoaded } = useUser();
  const query = useGetAccess({ query: { queryKey: [...getGetAccessQueryKey(), user?.id ?? "signed-out"], enabled: isLoaded, staleTime: 0 } });
  return { ...query, isLoading: !isLoaded || query.isPending };
}

export function useNotebook() {
  const { user } = useUser();
  const access = useAccess();
  const allowed = !!access.data?.allowed;
  const nb = useGetNotebook({ query: { queryKey: [...getGetNotebookQueryKey(), user?.id ?? "signed-out"], enabled: allowed && !!user } });
  return { ...nb, isLoading: access.isLoading || (allowed && nb.isPending), access: access.data };
}

export function useInvalidate() {
  const qc = useQueryClient();
  return () => {
    qc.invalidateQueries({ queryKey: getGetNotebookQueryKey() });
    qc.invalidateQueries({ queryKey: getGetAccessQueryKey() });
  };
}

export function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  return "Something went wrong. Please try again.";
}

export const approved = (cards: Card[]) => cards.filter((c) => c.status === "approved");
export const pending = (cards: Card[]) => cards.filter((c) => c.status === "pending");

export function mastery(c: Pick<Card, "attempts" | "correct">) {
  return c.attempts ? c.correct / c.attempts : 0;
}

export function pct(n: number) {
  return `${Math.round(n * 1000) / 10}%`;
}

export interface UnitStat {
  unit: string;
  cards: Card[];
  attempts: number;
  correct: number;
  practiced: number;
  mastered: number;
}

export function unitStats(cards: Card[]): UnitStat[] {
  const map = new Map<string, UnitStat>();
  for (const c of approved(cards)) {
    const u = map.get(c.unit) ?? { unit: c.unit, cards: [], attempts: 0, correct: 0, practiced: 0, mastered: 0 };
    u.cards.push(c);
    u.attempts += c.attempts;
    u.correct += c.correct;
    if (c.attempts > 0) u.practiced += 1;
    if (c.attempts >= 2 && mastery(c) >= 0.8) u.mastered += 1;
    map.set(c.unit, u);
  }
  return [...map.values()].sort((a, b) => a.unit.localeCompare(b.unit));
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
