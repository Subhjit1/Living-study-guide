import { useMemo, useState } from "react";
import { useRecordPractice } from "@workspace/api-client-react";
import { Check, RotateCcw } from "lucide-react";
import { useNotebook, approved, mastery, pct, useInvalidate, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, EmptyState, SourceQuote, Meter } from "@/components/kit";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Study() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  const [unit, setUnit] = useState("all");
  const [done, setDone] = useState<number[]>([]);
  const [shown, setShown] = useState(false);
  const record = useRecordPractice();
  const invalidate = useInvalidate();
  const { toast } = useToast();
  const cards = useMemo(() => (data ? approved(data.cards) : []), [data]);
  const units = useMemo(() => [...new Set(cards.map((c) => c.unit))].sort(), [cards]);

  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;
  if (cards.length === 0) return <div><PageHeader eyebrow="Study" title="One thing at a time." /><EmptyState title="Nothing to practise." body="Focused study uses approved items only." href="/review" cta="Review items" /></div>;

  const queue = cards.filter((c) => (unit === "all" || c.unit === unit) && !done.includes(c.id))
    .sort((a, b) => mastery(a) - mastery(b) || a.attempts - b.attempts);
  const c = queue[0];
  const answer = (correct: boolean) => {
    if (!c) return;
    record.mutate({ data: { cardId: c.id, correct } }, {
      onSuccess: () => { invalidate(); setDone((d) => [...d, c.id]); setShown(false); },
      onError: (e) => toast({ title: "Practice not saved", description: errMsg(e), variant: "destructive" }),
    });
  };

  return (
    <div>
      <PageHeader eyebrow="Study" title="One thing at a time.">Weakest concepts first. Each answer is logged to your mastery record.</PageHeader>
      <div className="mb-8 flex flex-wrap gap-2">
        {["all", ...units].map((u) => (
          <button key={u} onClick={() => { setUnit(u); setDone([]); setShown(false); }} data-testid={`button-unit-${u}`}
            className={`rounded-full border px-3 py-1 text-xs ${unit === u ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"}`}>{u === "all" ? "All units" : u}</button>
        ))}
      </div>
      {!c ? (
        <div className="rise rounded-lg bg-accent/60 p-10 text-center">
          <p className="font-display text-2xl italic">Session complete.</p>
          <p className="font-reading mt-2 text-muted-foreground">You worked through {done.length} concept{done.length === 1 ? "" : "s"}.</p>
          <Button className="mt-6" variant="outline" onClick={() => setDone([])} data-testid="button-restart"><RotateCcw className="mr-2 h-4 w-4" />Go again</Button>
        </div>
      ) : (
        <div key={c.id} className="rise mx-auto max-w-2xl rounded-xl border border-border bg-card p-8 md:p-12">
          <div className="flex items-center justify-between">
            <p className="eyebrow">{c.unit} · {queue.length} left</p>
            <span className="font-mono text-xs text-muted-foreground">{c.attempts ? `${pct(mastery(c))} recall` : "first time"}</span>
          </div>
          <Meter value={mastery(c)} className="mt-3" />
          <h2 className="font-display mt-8 text-3xl font-light leading-snug" data-testid="text-study-question">{c.question}</h2>
          {!shown ? (
            <Button className="mt-10" onClick={() => setShown(true)} data-testid="button-show-answer">Show answer</Button>
          ) : (
            <div className="rise mt-8 space-y-6">
              <p className="font-reading text-xl leading-relaxed" data-testid="text-study-answer">{c.answer}</p>
              <SourceQuote quote={c.quote} sourceTitle={c.sourceTitle} />
              <div className="flex flex-wrap gap-2 pt-2">
                <Button disabled={record.isPending} onClick={() => answer(true)} data-testid="button-knew"><Check className="mr-2 h-4 w-4" />I knew it</Button>
                <Button variant="outline" disabled={record.isPending} onClick={() => answer(false)} data-testid="button-not-yet">Not yet</Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
