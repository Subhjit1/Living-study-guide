import { useMemo, useState } from "react";
import { useUpdateCard } from "@workspace/api-client-react";
import { Search, Undo2 } from "lucide-react";
import { useNotebook, approved, mastery, pct, useInvalidate, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, EmptyState, SourceQuote } from "@/components/kit";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function LibraryPage() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  const [q, setQ] = useState("");
  const [unit, setUnit] = useState("all");
  const [open, setOpen] = useState<number | null>(null);
  const update = useUpdateCard();
  const invalidate = useInvalidate();
  const { toast } = useToast();
  const cards = useMemo(() => (data ? approved(data.cards) : []), [data]);
  const units = useMemo(() => [...new Set(cards.map((c) => c.unit))].sort(), [cards]);
  const list = cards.filter((c) => (unit === "all" || c.unit === unit) && `${c.title} ${c.question} ${c.answer} ${c.quote} ${c.sourceTitle}`.toLowerCase().includes(q.toLowerCase()));

  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;

  return (
    <div>
      <PageHeader eyebrow="Library" title="What you have accepted as true.">
        {cards.length} approved concepts, each with the line from your notes it came from.
      </PageHeader>
      {cards.length === 0 ? <EmptyState title="The shelves are empty." body="Approve items in Review to fill your library." href="/review" cta="Go to review" /> : (
        <>
          <div className="mb-6 flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input className="pl-9" placeholder="Search concepts, answers, quotes" value={q} onChange={(e) => setQ(e.target.value)} data-testid="input-search" />
            </div>
          </div>
          <div className="mb-8 flex flex-wrap gap-2">
            {["all", ...units].map((u) => (
              <button key={u} onClick={() => setUnit(u)} data-testid={`button-filter-${u}`}
                className={`rounded-full border px-3 py-1 text-xs transition-colors ${unit === u ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"}`}>
                {u === "all" ? "All units" : u}
              </button>
            ))}
          </div>
          {list.length === 0 && <p className="font-reading italic text-muted-foreground">No concept matches that search.</p>}
          <ul className="divide-y divide-border border-y border-border">
            {list.map((c) => (
              <li key={c.id} data-testid={`row-card-${c.id}`}>
                <button className="flex w-full items-baseline gap-4 py-5 text-left" onClick={() => setOpen(open === c.id ? null : c.id)} data-testid={`button-expand-${c.id}`}>
                  <span className="font-display flex-1 text-xl">{c.title}</span>
                  <span className="hidden font-mono text-xs text-muted-foreground sm:inline">{c.unit}</span>
                  <span className="font-mono text-xs text-muted-foreground">{c.attempts ? pct(mastery(c)) : "new"}</span>
                </button>
                {open === c.id && (
                  <div className="rise grid gap-6 pb-8 md:grid-cols-2">
                    <div>
                      <p className="eyebrow">Question</p>
                      <p className="font-reading mt-1 text-lg">{c.question}</p>
                      <p className="eyebrow mt-4">Answer</p>
                      <p className="font-reading mt-1 text-lg">{c.answer}</p>
                      <p className="mt-4 font-mono text-xs text-muted-foreground">{c.correct}/{c.attempts} correct</p>
                    </div>
                    <div>
                      <SourceQuote quote={c.quote} sourceTitle={c.sourceTitle} />
                      <Button variant="ghost" size="sm" className="mt-4" disabled={update.isPending} data-testid={`button-unapprove-${c.id}`}
                        onClick={() => update.mutate({ id: c.id, data: { status: "pending" } }, { onSuccess: () => { invalidate(); toast({ title: "Returned to review" }); }, onError: (e) => toast({ title: "Could not update", description: errMsg(e), variant: "destructive" }) })}>
                        <Undo2 className="mr-2 h-4 w-4" /> Send back to review
                      </Button>
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
