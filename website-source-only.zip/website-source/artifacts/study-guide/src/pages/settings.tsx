import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "wouter";
import { useAddSource, useUpdateSettings, useGetBackup, getGetBackupQueryKey, type Notebook } from "@workspace/api-client-react";
import { Upload, Download, FileText, LogIn } from "lucide-react";
import { useNotebook, useInvalidate, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState } from "@/components/kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

function download(name: string, body: string, type: string) {
  const url = URL.createObjectURL(new Blob([body], { type }));
  const a = document.createElement("a");
  a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function toMarkdown(nb: Notebook) {
  const lines = [`# ${nb.title}`, "", `Exported ${new Date().toISOString()}`, ""];
  for (const status of ["approved", "pending", "discarded"] as const) {
    const cs = nb.cards.filter((c) => c.status === status);
    lines.push(`## ${status[0].toUpperCase() + status.slice(1)} (${cs.length})`, "");
    for (const c of cs) {
      lines.push(`### ${c.title}`, `- Unit: ${c.unit}`, `- Source: ${c.sourceTitle}`, `- Practice: ${c.correct}/${c.attempts}`, "", `**Q:** ${c.question}`, "", `**A:** ${c.answer}`, "", `> ${c.quote}`, "");
    }
  }
  lines.push("## Sources", "");
  for (const s of nb.sources) lines.push(`### ${s.title}`, "", s.content, "");
  return lines.join("\n");
}

function Section({ title, note, children }: { title: string; note?: string; children: ReactNode }) {
  return (
    <section className="rise grid gap-6 border-b border-border py-10 md:grid-cols-[220px_1fr]">
      <div><h2 className="font-display text-xl">{title}</h2>{note && <p className="font-reading mt-2 text-sm text-muted-foreground">{note}</p>}</div>
      <div>{children}</div>
    </section>
  );
}

export default function SettingsPage() {
  const { data, isLoading, isError, error, refetch, access } = useNotebook();
  const { toast } = useToast();
  const invalidate = useInvalidate();
  const settings = useUpdateSettings();
  const addSource = useAddSource();
  const backup = useGetBackup({ query: { queryKey: getGetBackupQueryKey(), enabled: false } });
  const [title, setTitle] = useState("");
  const [srcTitle, setSrcTitle] = useState("");
  const [content, setContent] = useState("");
  const [openSource, setOpenSource] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const initTitle = useRef(false);
  useEffect(() => { if (data && !initTitle.current) { initTitle.current = true; setTitle(data.title); } }, [data]);

  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;

  const save = (body: { title?: string; protectionEnabled?: boolean; extractionEnabled?: boolean }, msg: string) =>
    settings.mutate({ data: body }, { onSuccess: () => { invalidate(); toast({ title: msg }); }, onError: (e) => toast({ title: "Setting not saved", description: errMsg(e), variant: "destructive" }) });

  const onFile = (f?: File) => {
    if (!f) return;
    if (!/\.(txt|md|markdown)$/i.test(f.name)) { toast({ title: "Use a .txt or .md file", variant: "destructive" }); return; }
    const r = new FileReader();
    r.onload = () => { setContent(String(r.result ?? "")); if (!srcTitle) setSrcTitle(f.name.replace(/\.(txt|md|markdown)$/i, "")); };
    r.readAsText(f);
  };

  const extract = () => addSource.mutate({ data: { title: srcTitle.trim(), content } }, {
    onSuccess: (nb) => { invalidate(); setSrcTitle(""); setContent(""); toast({ title: "Notes extracted", description: `${nb.cards.filter((c) => c.status === "pending").length} items now await review.` }); },
    onError: (e) => toast({ title: "Extraction failed", description: errMsg(e), variant: "destructive" }),
  });

  const runBackup = async (kind: "json" | "md") => {
    const r = await backup.refetch();
    if (r.error || !r.data) { toast({ title: "Backup failed", description: errMsg(r.error), variant: "destructive" }); return; }
    const stamp = new Date().toISOString().slice(0, 10);
    if (kind === "json") download(`study-guide-${stamp}.json`, JSON.stringify(r.data, null, 2), "application/json");
    else download(`study-guide-${stamp}.md`, toMarkdown(r.data), "text/markdown");
  };

  const signedIn = !!access?.signedIn;
  const contentOk = content.trim().length >= 30 && content.length <= 40000;

  return (
    <div>
      <PageHeader eyebrow="Settings" title="The notebook itself.">Import notes, keep backups, and decide who can open this.</PageHeader>

      <Section title="Title">
        <form className="flex flex-col gap-3 sm:flex-row" onSubmit={(e) => { e.preventDefault(); if (title.trim()) save({ title: title.trim() }, "Title saved"); }}>
          <Input value={title} maxLength={200} onChange={(e) => setTitle(e.target.value)} data-testid="input-notebook-title" />
          <Button type="submit" disabled={!title.trim() || title.trim() === data.title || settings.isPending} data-testid="button-save-title">Save</Button>
        </form>
      </Section>

      <Section title="Import notes" note="Paste text or load a .txt / .md file. Items are extracted with the exact line from your notes and wait for your review. Extraction can take around 30 seconds; the source is saved only if extraction succeeds.">
        {!data.extractionEnabled && <p className="mb-4 rounded-md bg-[hsl(var(--highlight)/0.35)] px-4 py-3 text-sm" data-testid="text-extraction-off">Extraction is switched off below. Turn it on to import.</p>}
        <div className="space-y-3">
          <Input placeholder="Source title, e.g. Week 4 — Deviance lecture" value={srcTitle} maxLength={200} onChange={(e) => setSrcTitle(e.target.value)} data-testid="input-source-title" />
          <Textarea rows={8} className="font-reading" placeholder="Paste your notes here" value={content} onChange={(e) => setContent(e.target.value)} data-testid="input-source-content" />
          <div className="flex flex-wrap items-center gap-2">
            <input ref={fileRef} type="file" accept=".txt,.md,.markdown,text/plain,text/markdown" className="hidden" onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ""; }} data-testid="input-file" />
            <Button variant="outline" onClick={() => fileRef.current?.click()} data-testid="button-choose-file"><Upload className="mr-2 h-4 w-4" />Load file</Button>
            <Button disabled={!data.extractionEnabled || !srcTitle.trim() || !contentOk || addSource.isPending} onClick={extract} data-testid="button-extract">
              {addSource.isPending ? "Reading your notes..." : "Extract items"}
            </Button>
            <span className="font-mono text-xs text-muted-foreground">{content.length.toLocaleString()} / 40,000{content.length > 0 && content.trim().length < 30 ? " · at least 30 characters" : ""}</span>
          </div>
        </div>
      </Section>

      <Section title="Sources" note={`${data.sources.length} saved. Every card links back to one of these.`}>
        {data.sources.length === 0 ? <p className="font-reading italic text-muted-foreground">No sources yet.</p> : (
          <ul className="divide-y divide-border border-y border-border">
            {data.sources.map((s) => {
              const cs = data.cards.filter((c) => c.sourceId === s.id);
              return (
                <li key={s.id} data-testid={`row-source-${s.id}`}>
                  <button className="flex w-full items-center gap-3 py-4 text-left" onClick={() => setOpenSource(openSource === s.id ? null : s.id)} data-testid={`button-source-${s.id}`}>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="flex-1">{s.title}</span>
                    <span className="font-mono text-xs text-muted-foreground">{cs.filter((c) => c.status === "approved").length} approved · {cs.filter((c) => c.status === "pending").length} pending · {new Date(s.createdAt).toLocaleDateString()}</span>
                  </button>
                  {openSource === s.id && <pre className="font-reading rise mb-4 max-h-80 overflow-auto whitespace-pre-wrap rounded-md bg-muted/60 p-4 text-sm leading-relaxed">{s.content}</pre>}
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      <Section title="Backup" note="Full export of every card in every status (approved, pending, discarded), practice records and source text.">
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" disabled={backup.isFetching} onClick={() => runBackup("json")} data-testid="button-backup-json"><Download className="mr-2 h-4 w-4" />JSON</Button>
          <Button variant="outline" disabled={backup.isFetching} onClick={() => runBackup("md")} data-testid="button-backup-md"><Download className="mr-2 h-4 w-4" />Markdown</Button>
        </div>
      </Section>

      <Section title="Extraction" note="A kill switch for automatic extraction. Existing items are unaffected.">
        <label className="flex items-center gap-3">
          <Switch checked={data.extractionEnabled} disabled={settings.isPending} onCheckedChange={(v) => save({ extractionEnabled: v }, v ? "Extraction on" : "Extraction off")} data-testid="switch-extraction" />
          <span className="text-sm">{data.extractionEnabled ? "Extraction is on" : "Extraction is off"}</span>
        </label>
      </Section>

      <Section title="Account privacy" note="Your notebook belongs only to your account.">
        <div className="space-y-4">
          <p className="font-reading text-[1.02rem]" data-testid="text-protection-status">
            {data.protectionEnabled
              ? "Protection is on. Only your signed-in account can open this notebook."
              : "Protection is off. This is an open development preview — anyone with the preview link can read and edit it. It is not private."}
          </p>
          {!signedIn && (
            <div className="rounded-md border border-border bg-card p-4">
              <p className="text-sm text-muted-foreground">Sign in to access your own private notebook.</p>
              <Link href="/sign-in" className="mt-3 inline-flex items-center rounded-md bg-primary px-3 py-2 text-sm text-primary-foreground" data-testid="link-settings-sign-in"><LogIn className="mr-2 h-4 w-4" />Sign in</Link>
            </div>
          )}
          <label className="flex items-center gap-3">
            <Switch checked disabled data-testid="switch-protection" />
            <span className="text-sm">Sign-in required — always private</span>
          </label>
          <div className="rounded-md bg-accent/50 p-4 text-sm leading-relaxed text-accent-foreground">
            <p className="font-medium">About publishing</p>
            <p className="mt-1">Anyone can create an account. Each account has its own private notes, cards, review queue, backups, and progress. No owner configuration is required. Preview and published accounts are separate.</p>
          </div>
        </div>
      </Section>
    </div>
  );
}
