import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useUpdateCard, useMergeCards, type Card } from "@workspace/api-client-react";
import { Check, Trash2, Combine, Save } from "lucide-react";
import { useNotebook, pending, useInvalidate, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, EmptyState } from "@/components/kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

type Draft = { title: string; question: string; answer: string; unit: string };

export default function Review() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  const items = useMemo(() => (data ? pending(data.cards) : []), [data]);
  const units = useMemo(() => [...new Set((data?.cards ?? []).map((c) => c.unit))].sort(), [data]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [selected, setSelected] = useState<number[]>([]);
  const [draft, setDraft] = useState<Draft | null>(null);
  const invalidate = useInvalidate();
  const { toast } = useToast();
  const update = useUpdateCard();
  const merge = useMergeCards();

  const active: Card | undefined = items.find((c) => c.id === activeId) ?? items[0];
  const activeKey = active?.id ?? null;
  useEffect(() => {
    if (!active) { setDraft(null); return; }
    setDraft({ title: active.title, question: active.question, answer: active.answer, unit: active.unit });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeKey]);

  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;

  const edited = !!(active && draft && (draft.title !== active.title || draft.question !== active.question || draft.answer !== active.answer || draft.unit !== active.unit));
  const valid = !!draft && draft.title.trim() && draft.question.trim() && draft.answer.trim() && draft.unit.trim();

  const act = (status: "approved" | "discarded" | "pending", withEdits: boolean) => {
    if (!active || !draft) return;
    const payload = withEdits ? { title: draft.title.trim(), question: draft.question.trim(), answer: draft.answer.trim(), unit: draft.unit.trim() } : {};
    const idx = items.findIndex((c) => c.id === active.id);
    update.mutate({ id: active.id, data: status === "pending" ? payload : { ...payload, status } }, {
      onSuccess: () => {
        invalidate();
        setSelected((s) => s.filter((x) => x !== active.id));
        if (status !== "pending") setActiveId(items[idx + 1]?.id ?? items[idx - 1]?.id ?? null);
        toast({ title: status === "approved" ? (withEdits && edited ? "Edited and approved" : "Approved") : status === "discarded" ? "Discarded" : "Edits saved" });
      },
      onError: (e) => toast({ title: "Could not save", description: errMsg(e), variant: "destructive" }),
    });
  };

  const selectedCards = items.filter((c) => selected.includes(c.id));
  const sameSource = selectedCards.length >= 2 && selectedCards.every((c) => c.sourceId === selectedCards[0].sourceId);
  const doMerge = () => merge.mutate({ data: { ids: selected } }, {
    onSuccess: (card) => { invalidate(); setSelected([]); setActiveId(card.id); toast({ title: `Merged ${selectedCards.length} items`, description: card.title }); },
    onError: (e) => toast({ title: "Merge failed", description: errMsg(e), variant: "destructive" }),
  });

  return (
    <div>
      <PageHeader eyebrow="Review" title="Read it against the source.">
        On the left, exactly what you wrote. On the right, how it will be studied. Approve only what holds up.
      </PageHeader>
      {items.length === 0 ? (
        <EmptyState title="Nothing waiting." body="Every extracted item has been approved or discarded. Import more notes to extract new ones." href="/settings" cta="Import notes" />
      ) : (
        <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
          <aside className="rise">
            <div className="mb-3 flex items-center justify-between">
              <p className="eyebrow">{items.length} pending</p>
              {selected.length > 0 && <button className="text-xs text-muted-foreground underline" onClick={() => setSelected([])} data-testid="button-clear-selection">clear</button>}
            </div>
            <ul className="max-h-[60vh] space-y-1 overflow-y-auto pr-1 lg:max-h-[70vh]">
              {items.map((c) => (
                <li key={c.id} className={`flex items-start gap-2 rounded-md px-2 py-2 transition-colors ${active?.id === c.id ? "bg-accent" : "hover:bg-muted"}`}>
                  <Checkbox className="mt-1" checked={selected.includes(c.id)} onCheckedChange={(v) => setSelected((s) => v ? [...s, c.id] : s.filter((x) => x !== c.id))} data-testid={`checkbox-select-${c.id}`} />
                  <button className="flex-1 text-left" onClick={() => setActiveId(c.id)} data-testid={`button-open-${c.id}`}>
                    <span className="block text-sm leading-snug">{c.title}</span>
                    <span className="block font-mono text-[0.65rem] text-muted-foreground">{c.unit} · {c.sourceTitle}</span>
                  </button>
                </li>
              ))}
            </ul>
            {selected.length > 0 && (
              <div className="mt-4 rounded-md border border-border bg-card p-3">
                <p className="text-xs text-muted-foreground">{selected.length} selected{selected.length >= 2 && !sameSource ? " — merging requires items from the same source." : ""}</p>
                <Button size="sm" className="mt-2 w-full" disabled={!sameSource || selected.length > 10 || merge.isPending} onClick={doMerge} data-testid="button-merge">
                  <Combine className="mr-2 h-4 w-4" />{merge.isPending ? "Merging..." : "Merge selected"}
                </Button>
              </div>
            )}
          </aside>

          {active && draft && (
            <div key={active.id} className="rise grid gap-6 md:grid-cols-2">
              <section className="rounded-lg border border-[hsl(var(--highlight))] bg-[hsl(var(--highlight)/0.18)] p-6">
                <p className="eyebrow">Source fact · verbatim</p>
                <blockquote className="font-reading mt-4 text-xl italic leading-relaxed" data-testid="text-source-quote"><span className="hl">{active.quote}</span></blockquote>
                <p className="mt-6 font-mono text-xs text-muted-foreground" data-testid="text-source-title">{active.sourceTitle}</p>
                <p className="font-reading mt-4 text-sm text-muted-foreground">This text cannot be edited. It is the anchor for everything on the right.</p>
              </section>
              <section className="rounded-lg border border-border bg-card p-6">
                <p className="eyebrow">Study interpretation · editable</p>
                <div className="mt-4 space-y-4">
                  <Field label="Concept"><Input value={draft.title} maxLength={200} onChange={(e) => setDraft({ ...draft, title: e.target.value })} data-testid="input-title" /></Field>
                  <Field label="Question"><Textarea rows={2} value={draft.question} onChange={(e) => setDraft({ ...draft, question: e.target.value })} data-testid="input-question" /></Field>
                  <Field label="Answer"><Textarea rows={3} value={draft.answer} onChange={(e) => setDraft({ ...draft, answer: e.target.value })} data-testid="input-answer" /></Field>
                  <Field label="Unit tag">
                    <Input list="unit-list" value={draft.unit} maxLength={100} onChange={(e) => setDraft({ ...draft, unit: e.target.value })} data-testid="input-unit" />
                    <datalist id="unit-list">{units.map((u) => <option key={u} value={u} />)}</datalist>
                  </Field>
                </div>
                <div className="mt-6 flex flex-wrap gap-2">
                  <Button disabled={!valid || update.isPending} onClick={() => act("approved", edited)} data-testid="button-approve">
                    <Check className="mr-2 h-4 w-4" />{edited ? "Edit & approve" : "Approve"}
                  </Button>
                  <Button variant="outline" disabled={!edited || !valid || update.isPending} onClick={() => act("pending", true)} data-testid="button-save">
                    <Save className="mr-2 h-4 w-4" />Save, keep pending
                  </Button>
                  <Button variant="ghost" className="text-destructive" disabled={update.isPending} onClick={() => act("discarded", false)} data-testid="button-discard">
                    <Trash2 className="mr-2 h-4 w-4" />Discard
                  </Button>
                </div>
              </section>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</span>{children}</label>;
}
