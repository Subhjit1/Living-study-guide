import { useMemo, useState } from "react";
import { useRecordPractice, type Card } from "@workspace/api-client-react";
import { Check, X, ArrowRight } from "lucide-react";
import { useNotebook, approved, shuffle, useInvalidate, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, EmptyState, SourceQuote } from "@/components/kit";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

type Mode = "choice" | "short";

export default function Quiz() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  const cards = useMemo(() => (data ? approved(data.cards) : []), [data]);
  const [mode, setMode] = useState<Mode>("choice");
  const [seed, setSeed] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [typed, setTyped] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [score, setScore] = useState({ right: 0, total: 0 });
  const record = useRecordPractice();
  const invalidate = useInvalidate();
  const { toast } = useToast();

  const ids = useMemo(() => cards.map((c) => c.id).join(","), [cards]);
  const round = useMemo(() => {
    if (cards.length === 0) return null;
    const card = cards[Math.floor(Math.random() * cards.length)];
    const others = [...new Set(cards.filter((c) => c.id !== card.id && c.answer !== card.answer).map((c) => c.answer))];
    const options = shuffle([card.answer, ...shuffle(others).slice(0, 3)]);
    return { card, options };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seed, ids]);

  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;
  if (!round) return <div><PageHeader eyebrow="Quiz" title="A small examination." /><EmptyState title="Nothing to quiz yet." body="Approve at least two items to unlock the quiz." href="/review" cta="Review items" /></div>;

  const log = (card: Card, correct: boolean) => {
    setScore((s) => ({ right: s.right + (correct ? 1 : 0), total: s.total + 1 }));
    record.mutate({ data: { cardId: card.id, correct } }, { onSuccess: invalidate, onError: (e) => toast({ title: "Practice not saved", description: errMsg(e), variant: "destructive" }) });
  };
  const next = () => { setPicked(null); setTyped(""); setRevealed(false); setSeed((s) => s + 1); };
  const { card, options } = round;
  const tooFew = mode === "choice" && options.length < 2;

  return (
    <div>
      <PageHeader eyebrow="Quiz" title="A small examination."
        aside={<p className="font-mono text-sm text-muted-foreground" data-testid="text-score">{score.right} / {score.total} this session</p>}>
        Distractors are your own other approved answers, so the quiz never invents anything.
      </PageHeader>
      <div className="mb-8 inline-flex rounded-md border border-border p-1">
        {(["choice", "short"] as Mode[]).map((m) => (
          <button key={m} onClick={() => { setMode(m); next(); }} data-testid={`button-mode-${m}`}
            className={`rounded px-4 py-1.5 text-sm transition-colors ${mode === m ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            {m === "choice" ? "Multiple choice" : "Short answer"}
          </button>
        ))}
      </div>
      <div key={`${seed}-${mode}`} className="rise max-w-3xl">
        <p className="eyebrow">{card.unit}</p>
        <h2 className="font-display mt-2 text-3xl font-light leading-snug" data-testid="text-quiz-question">{card.question}</h2>
        {tooFew ? (
          <p className="font-reading mt-6 text-muted-foreground">Multiple choice needs at least two different approved answers. Try short answer, or approve more items.</p>
        ) : mode === "choice" ? (
          <ul className="mt-8 space-y-3">
            {options.map((o, k) => {
              const isRight = o === card.answer;
              const state = picked === null ? "" : isRight ? "border-primary bg-accent" : picked === o ? "border-destructive/60 bg-destructive/5" : "opacity-60";
              return (
                <li key={k}>
                  <button disabled={picked !== null} onClick={() => { setPicked(o); log(card, isRight); }} data-testid={`button-option-${k}`}
                    className={`font-reading flex w-full gap-4 rounded-lg border border-border bg-card px-5 py-4 text-left text-[1.05rem] transition-all hover:-translate-y-0.5 disabled:hover:translate-y-0 ${state}`}>
                    <span className="font-mono text-xs text-muted-foreground pt-1">{"ABCD"[k]}</span>
                    <span className="flex-1">{o}</span>
                    {picked !== null && isRight && <Check className="h-5 w-5 text-primary" />}
                    {picked === o && !isRight && <X className="h-5 w-5 text-destructive" />}
                  </button>
                </li>
              );
            })}
          </ul>
        ) : (
          <div className="mt-8 space-y-4">
            <Textarea rows={4} placeholder="Answer in your own words" value={typed} disabled={revealed} onChange={(e) => setTyped(e.target.value)} data-testid="input-short-answer" />
            {!revealed ? (
              <Button onClick={() => setRevealed(true)} disabled={!typed.trim()} data-testid="button-reveal">Compare with my notes</Button>
            ) : (
              <div className="rise space-y-5 rounded-lg border border-border bg-card p-6">
                <div><p className="eyebrow">Correct answer</p><p className="font-reading mt-1 text-lg" data-testid="text-correct-answer">{card.answer}</p></div>
                {picked === null ? (
                  <div className="flex flex-wrap gap-2">
                    <p className="w-full text-sm text-muted-foreground">Be honest — did yours capture it?</p>
                    <Button onClick={() => { setPicked("y"); log(card, true); }} data-testid="button-self-correct"><Check className="mr-2 h-4 w-4" />I had it</Button>
                    <Button variant="outline" onClick={() => { setPicked("n"); log(card, false); }} data-testid="button-self-incorrect"><X className="mr-2 h-4 w-4" />Not quite</Button>
                  </div>
                ) : <p className="text-sm text-muted-foreground">Logged.</p>}
              </div>
            )}
          </div>
        )}
        {(picked !== null || tooFew) && (
          <div className="rise mt-8">
            <SourceQuote quote={card.quote} sourceTitle={card.sourceTitle} />
            <Button className="mt-6" onClick={next} data-testid="button-next-question">Next question<ArrowRight className="ml-2 h-4 w-4" /></Button>
          </div>
        )}
      </div>
    </div>
  );
}
