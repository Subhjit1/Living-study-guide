import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { useNotebook, approved, pending, unitStats, mastery, pct, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, Meter } from "@/components/kit";

export default function Overview() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;
  const ap = approved(data.cards);
  const pe = pending(data.cards);
  const discarded = data.cards.filter((c) => c.status === "discarded").length;
  const reviewed = ap.length + discarded;
  const completion = data.cards.length ? reviewed / data.cards.length : 0;
  const units = unitStats(data.cards);
  const weakest = [...ap].sort((a, b) => mastery(a) - mastery(b) || a.attempts - b.attempts)[0];
  const unpracticed = ap.filter((c) => c.attempts === 0).length;

  const actions = [
    pe.length > 0 && { href: "/review", label: `Review ${pe.length} pending item${pe.length === 1 ? "" : "s"}`, note: "Read each against its source before it enters practice." },
    unpracticed > 0 && { href: "/study", label: `Practise ${unpracticed} untouched concept${unpracticed === 1 ? "" : "s"}`, note: "Approved, but never tested yet." },
    weakest && weakest.attempts > 0 && { href: "/study", label: `Revisit "${weakest.title}"`, note: `Currently at ${pct(mastery(weakest))} recall.` },
    ap.length >= 2 && { href: "/quiz", label: "Take a short quiz", note: "Multiple choice drawn from your own answers." },
    data.sources.length === 0 && { href: "/settings", label: "Import your first notes", note: "Paste or upload .txt / .md." },
  ].filter(Boolean) as { href: string; label: string; note: string }[];

  return (
    <div>
      <PageHeader eyebrow="Overview" title={<>{data.title}</>}>
        Every concept here traces back to a sentence you wrote. Nothing enters practice until you approve it.
      </PageHeader>

      <section className="rise grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-4" style={{ animationDelay: "80ms" }}>
        {[
          ["Approved", ap.length, "stat-approved"],
          ["Pending review", pe.length, "stat-pending"],
          ["Units", units.length, "stat-units"],
          ["Sources", data.sources.length, "stat-sources"],
        ].map(([l, v, id]) => (
          <div key={id as string} className="bg-card p-6">
            <p className="eyebrow">{l}</p>
            <p className="font-display mt-2 text-4xl font-light" data-testid={`text-${id}`}>{v}</p>
          </div>
        ))}
      </section>

      <div className="mt-12 grid gap-12 md:grid-cols-[1.3fr_1fr]">
        <section className="rise" style={{ animationDelay: "160ms" }}>
          <h2 className="font-display text-2xl">Next, quietly</h2>
          <ol className="mt-5 divide-y divide-border border-y border-border">
            {actions.length === 0 && <li className="font-reading py-5 text-muted-foreground">You are caught up. Add more notes in Settings when you have them.</li>}
            {actions.map((a, i) => (
              <li key={i}>
                <Link href={a.href} className="group flex items-start gap-4 py-5" data-testid={`link-action-${i}`}>
                  <span className="font-mono text-xs text-muted-foreground pt-1">{String(i + 1).padStart(2, "0")}</span>
                  <span className="flex-1">
                    <span className="block text-[1.02rem] text-foreground">{a.label}</span>
                    <span className="font-reading block text-sm italic text-muted-foreground">{a.note}</span>
                  </span>
                  <ArrowRight className="mt-1 h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
                </Link>
              </li>
            ))}
          </ol>
        </section>

        <section className="rise space-y-8" style={{ animationDelay: "240ms" }}>
          <div className="rounded-lg bg-accent/60 p-6">
            <p className="eyebrow">Notebook completion</p>
            <p className="font-display mt-2 text-3xl font-light" data-testid="text-completion">{pct(completion)}</p>
            <Meter value={completion} className="mt-4 bg-card" />
            <p className="font-reading mt-3 text-sm text-muted-foreground">{reviewed} of {data.cards.length} extracted items reviewed ({discarded} discarded).</p>
          </div>
          <div>
            <h2 className="font-display text-xl">Units</h2>
            <ul className="mt-4 space-y-4">
              {units.length === 0 && <li className="font-reading text-sm text-muted-foreground">Approve items to form units.</li>}
              {units.map((u) => (
                <li key={u.unit} data-testid={`row-unit-${u.unit}`}>
                  <div className="flex justify-between text-sm"><span>{u.unit}</span><span className="font-mono text-xs text-muted-foreground">{u.cards.length} cards · {u.attempts ? pct(u.correct / u.attempts) : "—"}</span></div>
                  <Meter value={u.attempts ? u.correct / u.attempts : 0} className="mt-2" />
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}
