import { useNotebook, unitStats, mastery, pct, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, EmptyState, Meter } from "@/components/kit";

export default function Understanding() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;
  const units = unitStats(data.cards);
  return (
    <div>
      <PageHeader eyebrow="Understanding" title="Where your grasp is firm." aside={<div className="hidden md:block" aria-hidden><div className="book-scene float"><div className="book"><span className="pg" /><span className="pg" /><span className="pg" /><span className="cover" /><span className="card3d" /><span className="card3d two" /></div><div className="book-shadow" /></div></div>}>
        Recall rate is correct answers over attempts. A concept counts as mastered after two or more attempts at 80% or better.
      </PageHeader>
      {units.length === 0 ? <EmptyState title="No units yet." body="Approve items and practise them to see your understanding take shape." href="/review" cta="Review items" /> : (
        <div className="space-y-8">
          {units.map((u, k) => (
            <section key={u.unit} className="rise lift glass glass-edge rounded-2xl p-5 md:p-7" style={{ animationDelay: `${k * 70}ms` }} data-testid={`section-unit-${u.unit}`}>
              <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-[hsl(var(--cyan)/0.15)] pb-4">
                <h2 className="font-display text-2xl font-semibold">{u.unit}</h2>
                <p className="rounded-full border border-[hsl(var(--cyan)/0.2)] bg-[hsl(var(--royal)/0.1)] px-3 py-1 font-mono text-xs text-muted-foreground">{u.practiced}/{u.cards.length} practised · {u.mastered} mastered · {u.correct}/{u.attempts} correct · {u.attempts ? pct(u.correct / u.attempts) : "—"}</p>
              </div>
              <ul className="mt-4 space-y-1">
                {u.cards.map((c) => (
                  <li key={c.id} className="row-glow -mx-3 rounded-xl px-3 py-2.5 grid grid-cols-[1fr_auto] items-center gap-x-6 gap-y-1 sm:grid-cols-[1fr_200px_80px]">
                    <span className="font-reading text-[1.02rem] col-start-1 row-start-1">{c.title}</span>
                    <Meter value={mastery(c)} className="col-span-2 row-start-2 sm:col-span-1 sm:col-start-2 sm:row-start-1" />
                    <span className="text-right font-mono text-xs text-muted-foreground row-start-1 col-start-2 sm:col-start-3">{c.attempts ? `${c.correct}/${c.attempts}` : "unpractised"}</span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
