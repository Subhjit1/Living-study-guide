import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Shuffle } from "lucide-react";
import { useNotebook, approved, shuffle, errMsg } from "@/lib/notebook";
import { PageHeader, PageSkeleton, ErrorState, EmptyState, SourceQuote } from "@/components/kit";
import { Button } from "@/components/ui/button";

export default function Flashcards() {
  const { data, isLoading, isError, error, refetch } = useNotebook();
  const base = useMemo(() => (data ? approved(data.cards) : []), [data]);
  const [order, setOrder] = useState<number[] | null>(null);
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  if (isLoading) return <PageSkeleton />;
  if (isError || !data) return <ErrorState message={errMsg(error)} onRetry={() => refetch()} />;
  const deck = order ? order.map((id) => base.find((c) => c.id === id)).filter((c) => !!c) : base;
  if (deck.length === 0) return <div><PageHeader eyebrow="Flashcards" title="Turn the page." /><EmptyState title="No approved cards yet." body="Flashcards only draw from items you have approved." href="/review" cta="Review items" /></div>;
  const idx = Math.min(i, deck.length - 1);
  const c = deck[idx];
  const go = (d: number) => { setFlipped(false); setI((idx + d + deck.length) % deck.length); };

  return (
    <div>
      <PageHeader eyebrow="Flashcards" title="Turn the page."
        aside={<Button variant="outline" onClick={() => { setOrder(shuffle(base.map((x) => x.id))); setI(0); setFlipped(false); }} data-testid="button-shuffle"><Shuffle className="mr-2 h-4 w-4" />Shuffle</Button>}>
        Tap the card to see the answer and the line it came from.
      </PageHeader>
      <div className="flip-scene mx-auto max-w-2xl">
        <button className={`flip-inner relative block h-[380px] w-full ${flipped ? "flipped" : ""}`} onClick={() => setFlipped(!flipped)} data-testid="button-flip">
          <div className="flip-face ruled absolute inset-0 flex flex-col rounded-xl border border-border bg-card p-8 text-left shadow-[0_24px_60px_-34px_hsl(192_40%_20%/0.4)]">
            <p className="eyebrow">{c.unit} · question</p>
            <p className="font-display mt-auto mb-auto text-2xl font-light leading-snug md:text-3xl" data-testid="text-question">{c.question}</p>
            <p className="text-xs text-muted-foreground">Tap to turn</p>
          </div>
          <div className="flip-face flip-back absolute inset-0 flex flex-col overflow-y-auto rounded-xl border border-primary/30 bg-accent/70 p-8 text-left">
            <p className="eyebrow">answer</p>
            <p className="font-reading mt-3 text-xl leading-relaxed" data-testid="text-answer">{c.answer}</p>
            <SourceQuote className="mt-auto pt-6" quote={c.quote} sourceTitle={c.sourceTitle} />
          </div>
        </button>
        <div className="mt-6 flex items-center justify-between">
          <Button variant="ghost" onClick={() => go(-1)} data-testid="button-prev"><ChevronLeft className="mr-1 h-4 w-4" />Previous</Button>
          <span className="font-mono text-xs text-muted-foreground" data-testid="text-position">{idx + 1} / {deck.length}</span>
          <Button variant="ghost" onClick={() => go(1)} data-testid="button-next">Next<ChevronRight className="ml-1 h-4 w-4" /></Button>
        </div>
      </div>
    </div>
  );
}
