import { pool } from "@workspace/db";
import { GetNotebookResponse } from "@workspace/api-zod";
import type { z } from "zod";

export type Notebook = z.infer<typeof GetNotebookResponse>;
export type Card = Notebook["cards"][number];

const facts = [
  ["Socialization", "Socialization", "Socialization makes social life possible.", "What makes social life possible?"],
  ["Learning social life", "Socialization", "It teaches people how to communicate, cooperate, and understand what behavior is expected in different settings.", "What does socialization teach people?"],
  ["Primary socialization", "Socialization", "Primary socialization usually begins in childhood through family or caregivers and forms the foundational layer of identity and language.", "When and through whom does primary socialization usually begin?"],
  ["Secondary socialization", "Socialization", "Secondary socialization happens later as people enter new groups and institutions—such as schools, workplaces, peer groups, and civic organizations—where new settings add layers to what a person already learned early in life.", "How does secondary socialization build on early learning?"],
  ["Social roles", "Socialization", "The same person may act differently as a student, employee, teammate, sibling, or friend because each role carries different expectations.", "Why might one person act differently in different roles?"],
  ["Role strain", "Socialization", "Role strain occurs when competing demands are built into a single social role (for example, a manager expected to enforce strict deadlines while also acting as a supportive mentor).", "What is role strain?"],
  ["Role conflict", "Socialization", "Role conflict happens when expectations from two or more different roles clash (for example, an urgent work shift overlapping with a family obligation or final exam).", "What is role conflict?"],
  ["Social stratification", "Stratification", "Social stratification is a society's categorization of its people into rankings based on factors like wealth, income, education, family background, and power.", "What is social stratification?"],
  ["Shared norms", "Socialization", "Without socialization, individuals cannot internalize the norms, values, and shared symbols required to participate in society.", "What does socialization help people internalize?"],
  ["Role expectations", "Socialization", "Roles change by setting.", "What changes social roles?"],
  ["Performance and identity", "Socialization", "A changing performance does not necessarily mean a changing person; the setting changes the expectations.", "Does changing performance necessarily mean a changing person?"],
  ["Persistent inequality", "Stratification", "Stratification is a trait of society rather than simply a reflection of individual differences, and it persists across generations.", "Is stratification only a reflection of individual differences?"],
  ["Closed systems", "Stratification", "Closed stratification systems (such as caste systems) assign status by birth and allow little or no change in social position.", "How is status assigned in a closed stratification system?"],
  ["Open class systems", "Stratification", "Open class systems permit social mobility based on a combination of individual achievement, credentials, and broader economic structures.", "What influences mobility in open class systems?"],
  ["Intergenerational mobility", "Stratification", "Intergenerational mobility measures changes in social position between parents and their children, while intragenerational mobility tracks changes in a person's social status over their own lifetime.", "What does intergenerational mobility measure?"],
  ["Intragenerational mobility", "Stratification", "Intergenerational mobility measures changes in social position between parents and their children, while intragenerational mobility tracks changes in a person's social status over their own lifetime.", "What does intragenerational mobility track?"],
  ["Structural mobility", "Stratification", "Structural mobility happens when societal changes—such as industrialization, technological shifts, or recessions—enable a whole group of people to move up or down the social class ladder at the same time.", "What is structural mobility?"],
  ["Kill switch", "Safeguards", "In complex organizational systems, a kill switch exists to quickly disable risky behavior during an incident.", "What is the purpose of a kill switch?"],
  ["Human verification", "Safeguards", "Requiring human-in-the-loop verification before committing automated outputs prevents small extraction errors from compounding into systemic failures.", "Why verify automated outputs before committing them?"],
  ["Family and identity", "Socialization", "Primary socialization usually begins in childhood through family or caregivers and forms the foundational layer of identity and language.", "Which layers are formed through primary socialization?"],
  ["Institutions and learning", "Socialization", "Secondary socialization happens later as people enter new groups and institutions—such as schools, workplaces, peer groups, and civic organizations—where new settings add layers to what a person already learned early in life.", "Which institutions are examples of secondary socialization?"],
  ["Ranking factors", "Stratification", "Social stratification is a society's categorization of its people into rankings based on factors like wealth, income, education, family background, and power.", "Which factors can underlie social rankings?"],
  ["Economic change", "Stratification", "Structural mobility happens when societal changes—such as industrialization, technological shifts, or recessions—enable a whole group of people to move up or down the social class ladder at the same time.", "Which societal changes can produce structural mobility?"],
];

function seed(): Notebook {
  const createdAt = new Date().toISOString();
  const sourceTitle = "Sociology 101 — Socialization and Social Stratification";
  return {
    title: "Sociology 101", protectionEnabled: true, extractionEnabled: true,
    sources: [{ id: 1, title: sourceTitle, content: [...new Set(facts.map(f => f[2]))].join("\n\n"), createdAt }],
    cards: facts.map(([title, unit, quote, question], i) => ({
      id: i + 1, title: title!, unit: unit!, quote: quote!, question: question!,
      answer: quote!, sourceId: 1, sourceTitle, status: i < 8 ? "approved" : "pending",
      attempts: 0, correct: 0, createdAt,
    })),
  };
}

export async function loadNotebook(userId: string) {
  if (!userId) throw new Error("Authenticated user required");
  await pool.query("INSERT INTO account_notebooks (user_id,data) VALUES ($1,$2) ON CONFLICT (user_id) DO NOTHING", [userId, JSON.stringify(seed())]);
  const result = await pool.query("SELECT data FROM account_notebooks WHERE user_id=$1", [userId]);
  return { data: GetNotebookResponse.parse(result.rows[0].data) };
}

export async function mutateNotebook<T>(userId: string, fn: (data: Notebook) => T | Promise<T>) {
  if (!userId) throw new Error("Authenticated user required");
  await loadNotebook(userId);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query("SELECT data FROM account_notebooks WHERE user_id=$1 FOR UPDATE", [userId]);
    const data = GetNotebookResponse.parse(result.rows[0].data);
    const value = await fn(data);
    await client.query("UPDATE account_notebooks SET data=$1 WHERE user_id=$2", [JSON.stringify(data), userId]);
    await client.query("COMMIT");
    return value;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally { client.release(); }
}
