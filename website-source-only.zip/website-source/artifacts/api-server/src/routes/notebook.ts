import { Router, type IRouter, type Request } from "express";
import { getAuth } from "@clerk/express";
import { AddSourceBody, UpdateCardBody, MergeCardsBody, RecordPracticeBody, UpdateSettingsBody, GetNotebookResponse } from "@workspace/api-zod";
import { loadNotebook, mutateNotebook } from "../lib/notebook";
import { extractCards } from "../lib/extract";

const router: IRouter = Router();
function problem(message: string, status = 400) { return Object.assign(new Error(message), { status }); }
function identity(req: Request) {
  const userId = getAuth(req).userId;
  if (!userId) throw problem("Sign in to open your private notebook.", 401);
  return userId;
}
async function access(req: Request) {
  const signedIn = !!getAuth(req).userId;
  return { allowed: signedIn, protectionEnabled: true, signedIn, ownerConfigured: true };
}

router.get("/access", async (req, res) => { res.set("Cache-Control", "no-store").json(await access(req)); });
router.use(async (req, res, next) => {
  if (!["/notebook", "/cards", "/sources", "/practice", "/backup"].some(p => req.path === p || req.path.startsWith(p + "/"))) { next(); return; }
  res.set("Cache-Control", "no-store");
  if (!(await access(req)).allowed) { res.status(401).json({ error: "Sign in to open your private notebook." }); return; }
  next();
});
router.get("/notebook", async (req, res) => {
  const { data } = await loadNotebook(identity(req));
  res.json({ ...data, protectionEnabled: true });
});
router.get("/backup", async (req, res) => { res.json(GetNotebookResponse.parse((await loadNotebook(identity(req))).data)); });
router.patch("/cards/:id", async (req, res) => {
  const parsed = UpdateCardBody.safeParse(req.body);
  if (!parsed.success) throw problem("Invalid card fields.");
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id)) throw problem("Invalid card ID.");
  const card = await mutateNotebook(identity(req), data => {
    const card = data.cards.find(c => c.id === id);
    if (!card) throw problem("Card not found.", 404);
    Object.assign(card, parsed.data);
    return card;
  });
  res.json(card);
});
router.post("/cards/merge", async (req, res) => {
  const parsed = MergeCardsBody.safeParse(req.body);
  if (!parsed.success) throw problem("Select between 2 and 10 pending cards.");
  const card = await mutateNotebook(identity(req), data => {
    const ids = [...new Set(parsed.data.ids)];
    const cards = data.cards.filter(c => ids.includes(c.id));
    if (ids.length < 2 || cards.length !== ids.length || cards.some(c => c.status !== "pending")) throw problem("Only pending review cards can be merged.");
    if (new Set(cards.map(c => c.sourceId)).size !== 1) throw problem("Merge cards from the same source to preserve source attribution.");
    const first = cards[0]!;
    const combined = { ...first, id: Math.max(...data.cards.map(c => c.id), 0) + 1,
      title: cards.map(c => c.title).join(" / "), question: cards.map(c => c.question).join("\n\n"),
      answer: cards.map(c => c.answer).join("\n\n"), quote: cards.map(c => c.quote).join("\n\n[…]\n\n"),
      createdAt: new Date().toISOString(), attempts: 0, correct: 0 };
    cards.forEach(c => { c.status = "discarded"; });
    data.cards.push(combined);
    return combined;
  });
  res.json(card);
});
const extracting = new Set<string>();
router.post("/sources", async (req, res) => {
  const parsed = AddSourceBody.safeParse(req.body);
  if (!parsed.success) throw problem("Provide a title and 30–40,000 characters of notes.");
  const userId = identity(req);
  if (!(await loadNotebook(userId)).data.extractionEnabled) throw problem("AI extraction is paused in Notebook settings.", 409);
  if (extracting.has(userId)) throw problem("Another extraction is in progress. Please wait.", 429);
  extracting.add(userId);
  try {
    const candidates = await extractCards(parsed.data.content);
    const result = await mutateNotebook(userId, data => {
      if (!data.extractionEnabled) throw problem("Extraction was paused. No new notes or cards were saved.", 409);
      const source = { ...parsed.data, id: Math.max(0, ...data.sources.map(s => s.id)) + 1, createdAt: new Date().toISOString() };
      data.sources.push(source);
      let id = Math.max(0, ...data.cards.map(c => c.id));
      data.cards.push(...candidates.map(c => ({ ...c, id: ++id, sourceId: source.id, sourceTitle: source.title, status: "pending" as const, attempts: 0, correct: 0, createdAt: source.createdAt })));
      return data;
    });
    res.json(result);
  } catch (error) {
    if (error instanceof Error && "status" in error && Number(error.status) < 500) throw error;
    req.log.error("Source extraction failed");
    throw problem("Extraction could not be completed. Your notes have not been saved; please keep them and try again.", 502);
  } finally { extracting.delete(userId); }
});
router.post("/practice", async (req, res) => {
  const parsed = RecordPracticeBody.safeParse(req.body);
  if (!parsed.success) throw problem("Invalid practice result.");
  res.json(await mutateNotebook(identity(req), data => {
    const card = data.cards.find(c => c.id === parsed.data.cardId && c.status === "approved");
    if (!card) throw problem("Practice requires an approved library card.", 404);
    card.attempts++;
    if (parsed.data.correct) card.correct++;
    return card;
  }));
});
router.patch("/notebook/settings", async (req, res) => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) throw problem("Invalid notebook settings.");
  if (parsed.data.protectionEnabled === false) throw problem("Private notebooks always require sign-in.");
  res.json(await mutateNotebook(identity(req), data => {
    Object.assign(data, parsed.data);
    return data;
  }));
});

export default router;
