import { Router, type IRouter } from "express";
import healthRouter from "./health";
import notebookRouter from "./notebook";

const router: IRouter = Router();

router.use(healthRouter);
router.use(notebookRouter);

export default router;
